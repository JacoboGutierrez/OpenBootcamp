public class Main{
    public static void main(String[]args){
        suma(2,3,4);

        Coche miCoche = new Coche(); //nuevo objeto derivado de la clase Coche
        miCoche.incremento_puertas();
        miCoche.incremento_puertas();
        miCoche.incremento_puertas();
        miCoche.incremento_puertas();
        System.out.println("Incremento en puertas: " + miCoche.num_puertas);

    }
    public static void suma(int a,int b, int c){
        System.out.println("Suma: "+ (a + b + c));
    }
}

class Coche{
    public int num_puertas = 0;
    public void incremento_puertas(){ //TRADUCCION: Te presento al metodo incremento, este(this) hará(.) en num_puertas un incremento(++)
        this.num_puertas++;
    }
}